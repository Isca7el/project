# Личный проект «Мишка»

* Студент: [Georg Nikitin](https://up.htmlacademy.ru/htmlcss/26/user/1118677)
* Наставник: [Вадим Новаш](https://up.htmlacademy.ru/adaptive/18/user/8589)

---

<a href="https://htmlacademy.ru/intensive/adaptive"><img align="left" width="50" height="50" alt="HTML Academy" src="https://up.htmlacademy.ru/static/img/intensive/adaptive/logo-for-github-2.png"></a>

Репозиторий создан для обучения на профессиональном онлайн‑курсе «[HTML и CSS, уровень 2](https://htmlacademy.ru/intensive/adaptive)» от [HTML Academy](https://htmlacademy.ru).

